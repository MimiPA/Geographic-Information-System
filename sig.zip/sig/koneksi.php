<!--Koneksi ke database-->
<?php
$host = "localhost";
$username = "root";
$password ="";
$db ="fti"; //nama database
$conn = new mysqli($host, $username, $password, $db);
?>